const div = document.createElement("div");
div.className = "box";
const btn = document.createElement("button");
btn.innerText = "사과🍎";
div.appendChild(btn);
document.body.appendChild(div);
