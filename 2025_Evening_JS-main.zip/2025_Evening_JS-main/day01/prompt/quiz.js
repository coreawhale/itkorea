// const coffee_shop = window.prompt("당신의 자주가는 커피점은?");
// const coffee_favorite = window.prompt("당신이 자주 시키는 커피는?");
// const coffee_size = window.prompt("당신이 자주 시키는 사이즈는?");
// const coffee_bean = window.prompt("당신이 좋아하는 원두는?");

// window.alert(`${coffee_shop} 숍에  ${coffee_size}사이즈인 ${coffee_favorite}를 시키고 원두를 ${coffee_bean}으로 즐겨 마시는 당신은 커피 애호가!😁`);

// 자기소개 프롬프트
const your_name = window.prompt("your~ 이름은");
const your_major = window.prompt("your~ 전공은?");
const your_birth = window.prompt("your~ 생년월일은?");
const your_mbti = window.prompt("your~ MBTI?");
window.alert(`이름 ${your_name} 전공 ${your_major} 생년월일 ${your_birth} MBTI ${your_mbti}`);

// 배민 프롬프트
const baemin_type = window.prompt("시키는 종류는?");
const baemin_franchise = window.prompt("시키는 프렌차이즈는?");
const baemin_menu = window.prompt("시키는 메뉴는?");
const baemin_delivery = window.prompt("시키는 배달 방식은?");
const baemin_take_time = window.prompt("걸리는 시간은?");
window.alert(`${baemin_type}종류에서 ${baemin_franchise}프렌차이즈 집에서 ${baemin_menu}메뉴를 ${baemin_delivery} 방식으로 시키시는데 ${baemin_take_time}시간 걸리시군요!`);
