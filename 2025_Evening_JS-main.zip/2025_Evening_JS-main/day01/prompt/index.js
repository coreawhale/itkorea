const coffee = window.prompt("최애 커피");
window.console.log(`너의 최애 커피는 ${coffee}야!😁`);

// quiz.html + quiz.js
