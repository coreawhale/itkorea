// 변수를 세개 만들고
const name = "전수효";
const place = "김포";
const hobby = "조축";
// 결과 알럿으로

window.alert(`저의 이름은 ${name}이고, 사는곳은 ${place}이고, 취미는 ${hobby}입니다.`);

const cake = "치즈케이크";
cake = "망고케이크";
let cake1 = "녹차케이크";
var cake2 = "딸기케이크"; //절대쓰지마셈
