// window.console.log(1 + 9);

// variable(변수)
const ice = 1 + 9;
const fire = 10 - 2;

window.console.log(ice); // 10
window.console.log(fire); // 8

const place = "한강 마포";
// `(백틱)
window.console.log(`제가 사는 동네는 ${place}입니다.`);

// quiz.html , quiz.js

// 변수를 세개 만들고
// 1. 자기이름
// 2. 자기사는곳
// 3. 자기취미

// 결과 알럿으로 저의 이름은 ~~이고, 사는곳은 ~~이고, 취미는 ~~입니다.
