// window는 브라우저 말함
// window.alert("안녕하세요 제 이름 전수효입니다. MBTI는 ENTJ입니다.");
// window.prompt("당신의 최애 드라마는?");
// window.console.log("오늘 저녁 메뉴: 서브웨이");
// window.console.log("빵 종류: 플랫브래드");

// 콘솔 로그
// window.console.log("이름 : 전수효");
// window.console.log("MBTI : ENTJ");
// window.console.log("최애커피: 꿀아메리카노");
// window.console.log("여행가고싶은 나라: 이탈리아 ");
