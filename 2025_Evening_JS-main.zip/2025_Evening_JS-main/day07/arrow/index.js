const add = (x, y) => x + y;
const substract = (x, y) => x - y;
const square = (x) => x ** 2;
