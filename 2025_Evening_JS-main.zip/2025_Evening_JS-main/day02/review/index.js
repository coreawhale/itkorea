const todo = window.prompt("주말에 뭐해요?");
const food = window.prompt("뭐 먹고싶어요?");
window.console.log(`주말에 ${todo}일과 ${food} 음식을 드셔보세요!`);

const age = window.prompt("몇살?");
const number_age = Number(age);
window.console.log(`${number_age}나이는 ${2026 - number_age}년생이시군요!`);
