const btn = document.createElement("button");
btn.innerText = "피카츄";
btn.addEventListener("click", () => {
  alert("피카피카");
});
document.body.appendChild(btn);
