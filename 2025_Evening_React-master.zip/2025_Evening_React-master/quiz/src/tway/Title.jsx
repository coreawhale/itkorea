const Title = () => {
  return (
    <div
      style={{
        textAlign: "center",
        padding: "20px",
        fontSize: "20px",
      }}
    >
      이벤트 운임
    </div>
  );
};

export default Title;
