const Price = () => {
  return (
    <div
      style={{
        textAlign: "center",
        padding: "20px",
        fontSize: "20px",
      }}
    >
      매진
    </div>
  );
};

export default Price;
