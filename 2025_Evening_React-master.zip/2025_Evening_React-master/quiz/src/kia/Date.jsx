const Date = (props) => {
  return <span>{props.date}</span>;
};

export default Date;
