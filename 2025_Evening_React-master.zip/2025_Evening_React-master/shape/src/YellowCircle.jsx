const YellowCircle = () => {
  return <div style={{ borderRadius: "9999px", backgroundColor: "yellow", width: "100px", height: "100px" }}></div>;
};

export default YellowCircle;
