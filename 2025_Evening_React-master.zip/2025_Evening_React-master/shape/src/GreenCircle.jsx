const GreenCircle = () => {
  return <div style={{ borderRadius: "9999px", backgroundColor: "green", width: "100px", height: "100px" }}></div>;
};

export default GreenCircle;
