const RedCircle = () => {
  return <div style={{ borderRadius: "9999px", backgroundColor: "red", width: "100px", height: "100px" }}></div>;
};

export default RedCircle;
