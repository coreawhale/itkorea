const Coffee = () => {
  return <h1>아메리카노</h1>;
};
export default Coffee;
