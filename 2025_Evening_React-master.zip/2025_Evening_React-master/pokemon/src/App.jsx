function App() {
  return <>리액트 시작 쀼쀼</>;
}

export default App;
