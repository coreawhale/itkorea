import { VehicleStatusCardProps } from "../types/vehicleStatusCardType";

export const vehicleData: VehicleStatusCardProps[] = [
  { carName: "니로 EV", carNumber: "48로5682", carStatus: "미완료" },
  { carName: "쏘렌토", carNumber: "123가0987", carStatus: "대기" },
  { carName: "카니발", carNumber: "45가7854", carStatus: "대기" },
  { carName: "쏘렌토", carNumber: "67가5421", carStatus: "대기" },
  { carName: "쏘렌토", carNumber: "67가5421", carStatus: "대기" },
  { carName: "카니발", carNumber: "45가7854", carStatus: "완료" },
  { carName: "쏘렌토", carNumber: "67가5421", carStatus: "완료" },
  { carName: "카니발", carNumber: "45가7854", carStatus: "완료" },
  { carName: "니로 EV", carNumber: "48로5682", carStatus: "미완료" },

  { carName: "쏘렌토", carNumber: "67가5421", carStatus: "완료" },
];
